I don't love that we're just using the code from Prof. Matta's notes, feels wrong, but we were given explicit permission to do so.
